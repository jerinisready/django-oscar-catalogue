class RemovedInOscar20Warning(DeprecationWarning):
    pass
